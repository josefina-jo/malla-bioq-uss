const ramos = [
  {
    "id": "DQUI1045",
    "nombre": "Química General I",
    "semestre": 1,
    "prereqs": []
  },
  {
    "id": "DBIO1091",
    "nombre": "Biología Celular",
    "semestre": 1,
    "prereqs": []
  },
  {
    "id": "DCEX0002",
    "nombre": "Matemática",
    "semestre": 1,
    "prereqs": []
  },
  {
    "id": "BIOQA001",
    "nombre": "Introducción a la Bioquímica",
    "semestre": 1,
    "prereqs": []
  },
  {
    "id": "BIOQA002",
    "nombre": "Integrado de Habilidades Científicas",
    "semestre": 1,
    "prereqs": []
  },
  {
    "id": "FORI0001",
    "nombre": "Antropología",
    "semestre": 1,
    "prereqs": []
  },
  {
    "id": "DQUI1046",
    "nombre": "Química General II",
    "semestre": 2,
    "prereqs": [
      "DQUI1045"
    ]
  },
  {
    "id": "DBIO1088",
    "nombre": "Biología Molecular y Genética",
    "semestre": 2,
    "prereqs": [
      "DBIO1091"
    ]
  },
  {
    "id": "DQUI1052",
    "nombre": "Química Orgánica",
    "semestre": 2,
    "prereqs": [
      "DQUI1045"
    ]
  },
  {
    "id": "DCEX0003",
    "nombre": "Cálculo Diferencial",
    "semestre": 2,
    "prereqs": [
      "DCEX0002"
    ]
  },
  {
    "id": "DCEX0019",
    "nombre": "Física",
    "semestre": 2,
    "prereqs": [
      "DCEX0002"
    ]
  },
  {
    "id": "DBIO1094",
    "nombre": "Bioquímica General",
    "semestre": 3,
    "prereqs": [
      "DQUI1052"
    ]
  },
  {
    "id": "DQUI1047",
    "nombre": "Química Analítica Cualicuantitativa",
    "semestre": 3,
    "prereqs": [
      "DQUI1046"
    ]
  },
  {
    "id": "DQUI1055",
    "nombre": "Química Orgánica Avanzada",
    "semestre": 3,
    "prereqs": [
      "DQUI1052"
    ]
  },
  {
    "id": "BIOQC001",
    "nombre": "Biofísica",
    "semestre": 3,
    "prereqs": [
      "DCEX0019"
    ]
  },
  {
    "id": "FORI0002",
    "nombre": "Ética",
    "semestre": 3,
    "prereqs": [
      "FORI0001"
    ]
  },
  {
    "id": "DQUI1053",
    "nombre": "Fisicoquímica",
    "semestre": 4,
    "prereqs": [
      "DQUI1046"
    ]
  },
  {
    "id": "DQUI1054",
    "nombre": "Análisis Químico Instrumental",
    "semestre": 4,
    "prereqs": [
      "DQUI1047"
    ]
  },
  {
    "id": "DBIO1095",
    "nombre": "Microbiología General",
    "semestre": 4,
    "prereqs": [
      "DBIO1094"
    ]
  },
  {
    "id": "DCEX0005",
    "nombre": "Bioestadística",
    "semestre": 4,
    "prereqs": [
      "DCEX0002"
    ]
  },
  {
    "id": "DSPU0015",
    "nombre": "Salud Poblacional",
    "semestre": 4,
    "prereqs": []
  },
  {
    "id": "BIOQD001",
    "nombre": "Hito Evaluativo Integrativo",
    "semestre": 4,
    "prereqs": []
  },
  {
    "id": "DBIO1085",
    "nombre": "Fisiología Integrada",
    "semestre": 5,
    "prereqs": [
      "DBIO1091"
    ]
  },
  {
    "id": "DCEX0024",
    "nombre": "Bioestadística Avanzada",
    "semestre": 5,
    "prereqs": [
      "DCEX0005"
    ]
  },
  {
    "id": "BIOQE001",
    "nombre": "Unidad de Investigación I",
    "semestre": 5,
    "prereqs": [
      "DBIO1094"
    ]
  },
  {
    "id": "DSPU0016",
    "nombre": "Epidemiología",
    "semestre": 5,
    "prereqs": [
      "DSPU0015"
    ]
  },
  {
    "id": "FORI0003",
    "nombre": "Persona y Sociedad",
    "semestre": 5,
    "prereqs": [
      "FORI0002"
    ]
  },
  {
    "id": "BIOQF001",
    "nombre": "Biología Celular Avanzada",
    "semestre": 6,
    "prereqs": [
      "DBIO1085"
    ]
  },
  {
    "id": "BIOQF002",
    "nombre": "Bioquímica Avanzada",
    "semestre": 6,
    "prereqs": [
      "DBIO1095"
    ]
  },
  {
    "id": "BIOQF003",
    "nombre": "Biología Molecular Avanzada",
    "semestre": 6,
    "prereqs": [
      "DBIO1088"
    ]
  },
  {
    "id": "BIOQF004",
    "nombre": "Laboratorio Integrado de Bioquímica",
    "semestre": 6,
    "prereqs": [
      "DBIO1095"
    ]
  },
  {
    "id": "DEBI0002",
    "nombre": "Bioética",
    "semestre": 6,
    "prereqs": []
  },
  {
    "id": "ELECFORI01",
    "nombre": "Electivo I: Formación Integral",
    "semestre": 6,
    "prereqs": []
  },
  {
    "id": "BIOQG001",
    "nombre": "Química Fisiopatológica y Farmacológica",
    "semestre": 7,
    "prereqs": [
      "BIOQF002"
    ]
  },
  {
    "id": "BIOQG002",
    "nombre": "Inmunología",
    "semestre": 7,
    "prereqs": [
      "BIOQF001"
    ]
  },
  {
    "id": "BIOQG003",
    "nombre": "Genética Molecular",
    "semestre": 7,
    "prereqs": [
      "BIOQF003"
    ]
  },
  {
    "id": "BIOQG004",
    "nombre": "Microbiología Molecular",
    "semestre": 7,
    "prereqs": [
      "BIOQF003"
    ]
  },
  {
    "id": "BIOQG005",
    "nombre": "Bases de las Ciencias Ómicas y Bioinformáticas",
    "semestre": 7,
    "prereqs": [
      "BIOQF004"
    ]
  },
  {
    "id": "ELECFORI02",
    "nombre": "Electivo II: Formación Integral",
    "semestre": 7,
    "prereqs": []
  },
  {
    "id": "BIOQH001",
    "nombre": "Patología Molecular",
    "semestre": 8,
    "prereqs": [
      "BIOQG001"
    ]
  },
  {
    "id": "BIOQH002",
    "nombre": "Bioquímica Clínica",
    "semestre": 8,
    "prereqs": [
      "BIOQG002"
    ]
  },
  {
    "id": "ELECBIOQ01",
    "nombre": "Electivo III: Formación Integral",
    "semestre": 8,
    "prereqs": []
  },
  {
    "id": "BIOQH003",
    "nombre": "Unidad de Investigación II",
    "semestre": 8,
    "prereqs": [
      "BIOQF004"
    ]
  },
  {
    "id": "BIOQH004",
    "nombre": "Hito Evaluativo Interprofesional",
    "semestre": 8,
    "prereqs": []
  },
  {
    "id": "ELECFORI03",
    "nombre": "Electivo III: Formación Integral",
    "semestre": 8,
    "prereqs": []
  },
  {
    "id": "BIOQI001",
    "nombre": "Control de Calidad y Gestión de Laboratorio",
    "semestre": 9,
    "prereqs": []
  },
  {
    "id": "ELECBIOQ02",
    "nombre": "Electivo I",
    "semestre": 9,
    "prereqs": []
  },
  {
    "id": "BIOQI002",
    "nombre": "Unidad de Investigación III",
    "semestre": 9,
    "prereqs": [
      "BIOQH003"
    ]
  },
  {
    "id": "BIOQI003",
    "nombre": "Formulación de Proyectos",
    "semestre": 9,
    "prereqs": []
  },
  {
    "id": "ELECDGEE03",
    "nombre": "Gestión de Carrera y Desarrollo Profesional",
    "semestre": 9,
    "prereqs": []
  },
  {
    "id": "ELECBIOQ03",
    "nombre": "Electivo III",
    "semestre": 10,
    "prereqs": []
  },
  {
    "id": "BIOQJ001",
    "nombre": "Práctica Profesional",
    "semestre": 10,
    "prereqs": [
      "BIOQH003"
    ]
  },
  {
    "id": "BIOQJ002",
    "nombre": "Memoria de Título",
    "semestre": 10,
    "prereqs": [
      "BIOQI002"
    ]
  }
];
